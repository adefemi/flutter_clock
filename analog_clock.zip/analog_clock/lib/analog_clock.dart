// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';

import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:intl/intl.dart';
import 'package:vector_math/vector_math_64.dart' show radians;
import 'package:flutter/services.dart';

import 'container_hand.dart';
import 'drawn_hand.dart';

/// Total distance traveled by a second or a minute hand, each second or minute,
/// respectively.
final radiansPerTick = radians(360 / 60);

/// Total distance traveled by an hour hand, each hour, in radians.
final radiansPerHour = radians(360 / 12);

/// A basic analog clock.
///
/// You can do better than this!
class AnalogClock extends StatefulWidget {
  const AnalogClock(this.model);

  final ClockModel model;

  @override
  _AnalogClockState createState() => _AnalogClockState();
}

class _AnalogClockState extends State<AnalogClock> {
  var _now = DateTime.now();
  var _temperature = '';
  var _condition = '';
  var _location = '';
  Timer _timer;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    widget.model.addListener(_updateModel);
    // Set the initial values.
    _updateTime();
    _updateModel();
  }

  @override
  void didUpdateWidget(AnalogClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeRight,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    super.dispose();
  }

  void _updateModel() {
    _temperature = widget.model.temperatureString;
    setState(() {
      _temperature = _temperature.substring(0, _temperature.length - 2);
      _condition = widget.model.weatherString;
      _location = widget.model.location;
    });
  }

  void _updateTime() {
    setState(() {
      _now = DateTime.now();
      // Update once per second. Make sure to do it at the beginning of each
      // new second, so that the clock is accurate.
      _timer = Timer(
        Duration(seconds: 1) - Duration(milliseconds: _now.millisecond),
        _updateTime,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final lightBright = Theme.of(context).brightness == Brightness.light;
    final customTheme = lightBright
        ? Theme.of(context).copyWith(
            // Hour hand.
            primaryColor: Color(0xFF00E0FF),
            // Minute hand.
            highlightColor: Color(0xFF000000),
            hoverColor: Color(0xFFF8F8F8),
            // Second hand.
            accentColor: Color(0xFFFF6363),
            backgroundColor: Color(0xFFffffff),
          )
        : Theme.of(context).copyWith(
            primaryColor: Color(0xFF00E0FF),
            highlightColor: Color(0xFFffffff),
            accentColor: Color(0xFFFF6363),
            hoverColor: Color(0xFF727272),
            backgroundColor: Color(0xFF000000),
          );

    final time = DateFormat.Hms().format(DateTime.now());
    final deviceWidth = MediaQuery.of(context).size.width;
    final paddingAmount = deviceWidth * 0.05;
    final clockRadius = ((deviceWidth - paddingAmount*2)/2) * 0.8;

    return Semantics.fromProperties(
      properties: SemanticsProperties(
        label: 'Analog clock with time $time',
        value: time,
      ),
      child: AnimatedContainer(
        color: customTheme.backgroundColor,
        padding: EdgeInsets.symmetric(horizontal: paddingAmount),
        duration: Duration(milliseconds: 500),
        child: Stack(
          children: <Widget>[
            SizedBox.expand(
              child: Row(
                children: <Widget>[
                  Flexible(
                    child: Center(
                      child: Stack(
                        children: <Widget>[
                          alignWrapper(
                              Container(
                                width: clockRadius,
                                height: clockRadius,
                                decoration: BoxDecoration(
                                    color: customTheme.highlightColor.withOpacity(lightBright ? 0.02 : 0.17),
                                    borderRadius: BorderRadius.circular(clockRadius * 2)
                                ),
                              )
                          ),
                          alignWrapper(
                              Container(
                                width: clockRadius * 0.85,
                                height: clockRadius * 0.85,
                                decoration: BoxDecoration(
                                    color: customTheme.backgroundColor,
                                    borderRadius: BorderRadius.circular((clockRadius * 0.85) * 2),
                                    boxShadow: [BoxShadow(
                                      color: Colors.black.withOpacity(0.05),
                                      blurRadius: 20.0,
                                    )]
                                ),
                              )
                          ),
                          alignWrapper(
                              Container(
                                child: clockHandConfig(customTheme),
                              )
                          ),
                          alignWrapper(
                              Container(
                                width: clockRadius * 0.04,
                                height: clockRadius * 0.04,
                                decoration: BoxDecoration(
                                    color: customTheme.hoverColor,
                                    border: Border.all(
                                      width: 0.5,
                                      color: customTheme.highlightColor.withOpacity(0.2)
                                    ),
                                    borderRadius: BorderRadius.circular(clockRadius * 0.04 * 2)
                                ),
                              )
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Flexible(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(top: 8),
                              child: Icon(Icons.ac_unit, size: 16, color: customTheme.accentColor,),
                            ),
                            Text(_temperature, style: TextStyle(
                                fontSize: 36,
                                color: customTheme.highlightColor.withOpacity(0.8),
                                fontFamily: "Montserrat"
                            ),),
                            Container(
                              margin: EdgeInsets.only(top: 5),
                              child: Text('°C', style: TextStyle(
                                fontSize: 18,
                                color: customTheme.highlightColor.withOpacity(0.8),
                                fontFamily: "Montserrat"
                              ),),
                            ),
                          ],
                        ),
                        SizedBox(height: 20,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(Icons.person_pin_circle, color: customTheme.primaryColor,),
                            SizedBox(width: 10,),
                            Text(_location, style: TextStyle(
                              fontSize: 20,
                              color: customTheme.highlightColor.withOpacity(0.8),
                              fontFamily: "Montserrat"
                            ),)
                          ],
                        )
                      ],
                    ),
                    flex: 1,
                  )
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 5),
              child: Row(
                children: <Widget>[
                  Icon(Icons.cloud_queue, color: customTheme.highlightColor,),
                  SizedBox(width: 5,),
                  Text(_condition, style: TextStyle(
                      fontFamily: "Montserrat",
                      color: customTheme.highlightColor
                  ),)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

//  Container(
//  color: customTheme.backgroundColor,
//  child: clockHandConfig(customTheme),
//  )

  Widget clockHandConfig(customTheme){
    return Stack(
      children: [
        ContainerHand(
          color: Colors.transparent,
          size: 0.35,
          angleRadians: _now.hour * radiansPerHour +
              (_now.minute / 60) * radiansPerHour,
          child: Transform.translate(
            offset: Offset(0.0, -75.0),
            child: Container(
              width: 10,
              height: 150,
              decoration: BoxDecoration(
                color: customTheme.primaryColor,
              ),
            ),
          ),
        ),
        DrawnHand(
          color: customTheme.primaryColor.withOpacity(0.4),
          thickness: 4,
          size: 0.45,
          angleRadians: _now.minute * radiansPerTick,
        ),
        DrawnHand(
          color: customTheme.accentColor,
          thickness: 2,
          size: 0.55,
          angleRadians: _now.second * radiansPerTick,
        ),
      ],
    );
  }

  Widget alignWrapper(component){
    return Align(
      alignment: Alignment.center,
      child: component,
    );
  }
}
